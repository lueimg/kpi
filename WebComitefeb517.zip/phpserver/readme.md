* configurar apache con override all virtual host

# reports
#######
-- insert into KPI_REPORTS values( kpi_reports_seq.nextval, 'test')
CREATE SEQUENCE kpi_reports_seq START WITH 1;
CREATE SEQUENCE kpi_queries_seq START WITH 1;
CREATE SEQUENCE kpi_subreports_seq START WITH 1;
CREATE SEQUENCE kpi_content_seq START WITH 1;
CREATE SEQUENCE kpi_series_seq START WITH 1;
CREATE SEQUENCE kpi_content_fields_seq START WITH 1;
CREATE SEQUENCE kpi_comments_seq START WITH 1;
CREATE SEQUENCE kpi_yaxis_seq START WITH 1;

# CREATE SEQUENCE kpi_graphics_seq START WITH 1;
#####
