<?php
// base on https://github.com/progknife/slim3-rest
require 'vendor/autoload.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$configuration = [
    'settings' => [
        'displayErrorDetails' => true,
    ],
];
$c = new \Slim\Container($configuration);

// use Psr\Http\Message\RequestInterface as Request;
// use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

$app = new \Slim\App($c);

/**
 * Formats string to StudlyCaps using delimiter to determine the next word and
 * finally removes the delimiter from string.
 *
 * @param string
 * @param string
 * @return string
 */
function stringToStudlyCaps($str) {
   
    $str = ucwords($str);
    return $str;
}

/**
 * Permanently redirect paths with a trailing slash to their non-trailing
 * counterpart.
 *
 * @see http://www.slimframework.com/docs/cookbook/route-patterns.html
 */
$app->add(function (Request $request, Response $response, callable $next) {
    $uri = $request->getUri();
    $path = $uri->getPath();
    //echo substr($path, -1);
    if ($path != '/' && substr($path, -1) == '/') {
        $uri = $uri->withPath(substr($path, 0, -1));

        return $response->withRedirect((string)$uri, 301);
    }

    return $next($request, $response);
});

/**
 * Handle request and process response.
 *
 * Loads controller based endpoint and calls the controller's method based on the
 * request method.
 *
 */
$app->any('/[{controller}[/{segments:.+}]]', function (Request $request, Response $response, $args) {
    if (!count($args)) {
        $args['controller'] = strtolower(\App\Controller\Controller::DEFAULT_CONTROLLER);
    }

    $class_name = sprintf( 'App\\Controller\\%s', stringToStudlyCaps($args['controller'])
    );
    
    if (class_exists($class_name)) {
        $controller = new $class_name($request, $response);
        $response = $controller->getRequestResponse();
    } else {
        $response = $response->withStatus(404)->write('Not Found');
    }

    return $response;
});

$app->run();
